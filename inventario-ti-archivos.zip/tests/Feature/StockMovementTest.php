<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use App\Services\StockService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class StockMovementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->actingAs(User::factory()->create());
    }

    private function product(int $stock = 10, string $name = 'Mouse Test'): Product
    {
        return Product::create([
            'category_id' => Category::firstOrCreate(['name' => 'Accesorios'])->id,
            'supplier_id' => Supplier::firstOrCreate(['name' => 'TechPerú'])->id,
            'name'        => $name,
            'price'       => 10,
            'stock'       => $stock,
        ]);
    }

    public function test_entry_increases_stock_and_is_logged(): void
    {
        $p = $this->product(10);

        $this->post(route('stock-movements.store'), [
            'product_id' => $p->id, 'type' => 'in', 'quantity' => 5, 'reason' => 'Compra a proveedor',
        ])->assertRedirect(route('stock-movements.index'));

        $this->assertSame(15, $p->fresh()->stock);
        $this->assertDatabaseHas('stock_movements', [
            'product_id' => $p->id, 'type' => 'in', 'quantity' => 5, 'stock_before' => 10, 'stock_after' => 15,
        ]);
    }

    public function test_exit_decreases_stock_and_is_logged(): void
    {
        $p = $this->product(10);

        $this->post(route('stock-movements.store'), [
            'product_id' => $p->id, 'type' => 'out', 'quantity' => 4, 'reason' => 'Venta',
        ]);

        $this->assertSame(6, $p->fresh()->stock);
        $this->assertDatabaseHas('stock_movements', ['type' => 'out', 'quantity' => 4, 'stock_before' => 10, 'stock_after' => 6]);
    }

    public function test_exit_cannot_exceed_available_stock(): void
    {
        $p = $this->product(3);

        $this->post(route('stock-movements.store'), [
            'product_id' => $p->id, 'type' => 'out', 'quantity' => 5, 'reason' => 'Venta',
        ])->assertSessionHasErrors('quantity');

        $this->assertSame(3, $p->fresh()->stock);
        $this->assertDatabaseCount('stock_movements', 0);
    }

    public function test_reason_must_match_the_movement_type(): void
    {
        $p = $this->product();

        $this->post(route('stock-movements.store'), [
            'product_id' => $p->id, 'type' => 'in', 'quantity' => 1, 'reason' => 'Venta',
        ])->assertSessionHasErrors('reason');
    }

    public function test_creating_a_product_with_stock_logs_the_initial_entry(): void
    {
        $this->post(route('products.store'), [
            'category_id' => Category::create(['name' => 'Cat'])->id,
            'supplier_id' => Supplier::create(['name' => 'Sup'])->id,
            'name' => 'Nuevo', 'price' => 20, 'stock' => 7,
        ]);

        $p = Product::where('name', 'Nuevo')->first();
        $this->assertSame(7, $p->stock);
        $this->assertDatabaseHas('stock_movements', ['product_id' => $p->id, 'type' => 'in', 'quantity' => 7, 'reason' => 'Stock inicial']);
    }

    public function test_changing_stock_from_edit_logs_a_manual_adjustment(): void
    {
        $p = $this->product(10);

        $this->put(route('products.update', $p), [
            'category_id' => $p->category_id, 'supplier_id' => $p->supplier_id,
            'name' => $p->name, 'price' => 10, 'stock' => 4,
        ])->assertRedirect(route('products.index'));

        $this->assertSame(4, $p->fresh()->stock);
        $this->assertDatabaseHas('stock_movements', ['product_id' => $p->id, 'type' => 'out', 'quantity' => 6, 'reason' => 'Ajuste manual']);
    }

    public function test_deleting_a_product_keeps_its_history(): void
    {
        $p = $this->product(5, 'Producto Borrable');

        $this->delete(route('products.destroy', $p))->assertRedirect(route('products.index'));

        $this->assertDatabaseMissing('products', ['id' => $p->id]);
        $this->assertDatabaseHas('stock_movements', [
            'product_id' => null, 'product_name' => 'Producto Borrable', 'type' => 'out', 'quantity' => 5, 'reason' => 'Producto eliminado',
        ]);
    }

    public function test_index_can_filter_by_type_and_export_csv(): void
    {
        $svc = app(StockService::class);
        $svc->record($this->product(0, 'Teclado Zeta'), 'in', 5, 'Compra a proveedor');
        $svc->record($this->product(9, 'Mouse Omega'), 'out', 2, 'Venta');

        $this->get(route('stock-movements.index', ['type' => 'out']))
            ->assertOk()->assertSee('Mouse Omega')->assertDontSee('Teclado Zeta');

        $this->get(route('stock-movements.export'))->assertOk()->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }
}
