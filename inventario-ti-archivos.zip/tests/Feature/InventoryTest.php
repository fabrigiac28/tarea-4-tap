<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class InventoryTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->actingAs(User::factory()->create());
    }

    private function payload(array $override = []): array
    {
        $category = Category::firstOrCreate(['name' => 'Accesorios']);
        $supplier = Supplier::firstOrCreate(['name' => 'TechPerú']);

        return array_merge([
            'category_id' => $category->id,
            'supplier_id' => $supplier->id,
            'sku'         => 'ACC-001',
            'name'        => 'Mouse',
            'price'       => 45.50,
            'stock'       => 10,
        ], $override);
    }

    public function test_dashboard_loads(): void
    {
        $this->get('/')->assertOk();
    }

    public function test_can_create_a_product(): void
    {
        $this->post(route('products.store'), $this->payload())
            ->assertRedirect(route('products.index'));

        $this->assertDatabaseHas('products', ['name' => 'Mouse', 'sku' => 'ACC-001']);
    }

    public function test_negative_price_and_empty_name_are_rejected(): void
    {
        $this->post(route('products.store'), $this->payload(['price' => -5, 'name' => '']))
            ->assertSessionHasErrors(['price', 'name']);
    }

    public function test_sku_must_be_unique(): void
    {
        Product::create($this->payload());

        $this->post(route('products.store'), $this->payload(['name' => 'Otro']))
            ->assertSessionHasErrors('sku');
    }

    public function test_cannot_delete_category_or_supplier_with_products(): void
    {
        $product = Product::create($this->payload());

        $this->delete(route('categories.destroy', $product->category_id))->assertSessionHas('error');
        $this->delete(route('suppliers.destroy', $product->supplier_id))->assertSessionHas('error');

        $this->assertDatabaseHas('categories', ['id' => $product->category_id]);
        $this->assertDatabaseHas('suppliers', ['id' => $product->supplier_id]);
    }

    public function test_search_and_low_stock_filter(): void
    {
        Product::create($this->payload(['sku' => 'A-1', 'name' => 'Teclado', 'stock' => 2]));
        Product::create($this->payload(['sku' => 'A-2', 'name' => 'Mouse',   'stock' => 50]));

        $this->get(route('products.index', ['q' => 'Teclado']))
            ->assertSee('Teclado')->assertDontSee('Mouse');

        $this->get(route('products.index', ['low' => 1]))
            ->assertSee('Teclado')->assertDontSee('Mouse');
    }
}
