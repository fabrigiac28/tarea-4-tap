<?php

// Mensajes de validación en español (solo las reglas usadas en este taller).
// Las reglas no listadas aquí usan el idioma de respaldo (en).
return [
    'required' => 'El campo :attribute es obligatorio.',
    'string'   => 'El campo :attribute debe ser un texto.',
    'email'    => 'El campo :attribute debe ser un correo válido.',
    'numeric'  => 'El campo :attribute debe ser un número.',
    'integer'  => 'El campo :attribute debe ser un número entero.',
    'date'     => 'El campo :attribute debe ser una fecha válida.',
    'in'       => 'El :attribute seleccionado no es válido.',
    'unique'   => 'El valor de :attribute ya está registrado.',
    'exists'   => 'El :attribute seleccionado no es válido.',
    'max' => [
        'numeric' => 'El campo :attribute no debe ser mayor que :max.',
        'string'  => 'El campo :attribute no debe superar los :max caracteres.',
    ],
    'min' => [
        'numeric' => 'El campo :attribute debe ser al menos :min.',
        'string'  => 'El campo :attribute debe tener al menos :min caracteres.',
    ],
    'attributes' => [
        'name'        => 'nombre',
        'description' => 'descripción',
        'email'       => 'correo',
        'phone'       => 'teléfono',
        'address'     => 'dirección',
        'category_id' => 'categoría',
        'supplier_id' => 'proveedor',
        'price'       => 'precio',
        'stock'       => 'stock',
        'sku'         => 'SKU',
        'type'        => 'tipo',
        'quantity'    => 'cantidad',
        'reason'      => 'motivo',
        'notes'       => 'notas',
        'password'    => 'contraseña',
        'from'        => 'fecha inicial',
        'to'          => 'fecha final',
        'product_id'  => 'producto',
    ],
];
