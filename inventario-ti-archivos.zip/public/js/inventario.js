(function () {
  // --- Tema claro / oscuro ---
  const root = document.documentElement;
  const themeBtn = document.getElementById('themeToggle');
  const paintThemeIcon = () => {
    if (!themeBtn) return;
    themeBtn.innerHTML = root.getAttribute('data-bs-theme') === 'dark'
      ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon-stars"></i>';
  };
  paintThemeIcon();
  themeBtn && themeBtn.addEventListener('click', () => {
    const next = root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-bs-theme', next);
    try { localStorage.setItem('theme', next); } catch (e) {}
    paintThemeIcon();
    window.dispatchEvent(new Event('themechange'));
  });

  // --- Menú lateral en móvil ---
  const sb = document.getElementById('sidebar');
  const bd = document.getElementById('backdrop');
  const toggle = () => { sb.classList.toggle('open'); bd.classList.toggle('show'); };
  document.getElementById('menuToggle')?.addEventListener('click', toggle);
  bd?.addEventListener('click', toggle);

  // --- Toasts ---
  document.querySelectorAll('.toast').forEach(el => new bootstrap.Toast(el, { delay: 4500 }).show());

  // --- Confirmación de eliminación con modal ---
  const modalEl = document.getElementById('confirmModal');
  if (modalEl) {
    const modal = new bootstrap.Modal(modalEl);
    const text = document.getElementById('confirmText');
    let pending = null;
    document.addEventListener('submit', e => {
      const f = e.target;
      if (f.matches('form[data-confirm]')) {
        e.preventDefault();
        pending = f;
        text.textContent = f.dataset.confirm;
        modal.show();
      }
    });
    document.getElementById('confirmOk').addEventListener('click', () => { if (pending) pending.submit(); });
  }
})();
