<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\User;
use App\Services\StockService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /** Datos de ejemplo. Se puede ejecutar varias veces sin duplicar. */
    public function run(): void
    {
        // Usuario de acceso (cámbiale la contraseña después de la práctica)
        User::firstOrCreate(
            ['email' => 'admin@senati.pe'],
            ['name' => 'Administrador', 'password' => Hash::make('Admin12345')]
        );

        $categories = collect([
            'Laptops'        => 'Equipos portátiles de alto rendimiento.',
            'Monitores'      => 'Pantallas para computadoras.',
            'Accesorios'     => 'Mouse, teclados, audífonos, etc.',
            'Almacenamiento' => 'Discos duros, SSD y memorias USB.',
        ])->map(fn ($desc, $name) => Category::firstOrCreate(['name' => $name], ['description' => $desc]));

        $suppliers = collect([
            ['name' => 'TechPerú S.A.C.',   'email' => 'ventas@techperu.com',     'phone' => '987654321', 'address' => 'Av. Arequipa 1234, Lima'],
            ['name' => 'Global Import',     'email' => 'info@globalimport.com',   'phone' => '954321987', 'address' => 'Jr. Lampa 456, Lima'],
            ['name' => 'Digital Solutions', 'email' => 'contacto@digitalsol.com', 'phone' => '945678123', 'address' => 'Av. Wilson 789, Lima'],
        ])->map(fn ($s) => Supplier::firstOrCreate(['name' => $s['name']], $s));

        // [sku, nombre, categoría, índice proveedor, precio, stock final]
        $products = [
            ['LAP-001', 'Laptop HP 15.6"',     'Laptops',        0, 2500.00, 10],
            ['LAP-002', 'Laptop Lenovo 14"',   'Laptops',        1, 2200.00,  3],
            ['MON-001', 'Monitor LG 24"',      'Monitores',      1,  750.00, 15],
            ['MON-002', 'Monitor Samsung 27"', 'Monitores',      1,  980.00,  4],
            ['ACC-001', 'Mouse Logitech',      'Accesorios',     2,   45.00, 50],
            ['ACC-002', 'Teclado mecánico',    'Accesorios',     2,  120.00, 25],
            ['ACC-003', 'Audífonos Bluetooth', 'Accesorios',     2,   85.00,  2],
            ['ALM-001', 'SSD 1TB',             'Almacenamiento', 0,  320.00,  8],
            ['ALM-002', 'Disco duro 2TB',      'Almacenamiento', 0,  280.00,  0],
            ['ALM-003', 'Memoria USB 64GB',    'Almacenamiento', 2,   25.00, 60],
        ];

        $stock = app(StockService::class);

        foreach ($products as $i => [$sku, $name, $category, $supplierIndex, $price, $final]) {
            $product = Product::firstOrCreate(['sku' => $sku], [
                'name'        => $name,
                'category_id' => $categories[$category]->id,
                'supplier_id' => $suppliers[$supplierIndex]->id,
                'price'       => $price,
                'stock'       => 0,
            ]);

            if (! $product->wasRecentlyCreated) {
                continue; // ya tenía historial
            }

            // Historial de ejemplo que termina exactamente en el stock final
            $bought   = $final >= 10 ? 5 : 0;
            $returned = ($i % 2 === 0 && $final >= 1) ? 1 : 0;
            $initial  = $final + 3 - $bought - $returned;
            $soldDay  = $i % 7;

            $stock->record($product, 'in', $initial, 'Stock inicial', null, now()->subDays(20 - $i));
            if ($bought) {
                $stock->record($product, 'in', $bought, 'Compra a proveedor', 'Reposición mensual', now()->subDays(8 + $i % 3));
            }
            $outAt = now()->subDays($soldDay)->subHours($i + 1);
            $stock->record($product, 'out', 3, 'Venta', null, $outAt);
            if ($returned) {
                $stock->record($product, 'in', 1, 'Devolución de cliente', null, $outAt->copy()->addMinutes(30));
            }
        }
    }
}
