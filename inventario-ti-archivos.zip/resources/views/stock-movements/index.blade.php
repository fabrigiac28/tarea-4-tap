@extends('layouts.app')
@section('title', 'Movimiento de stock')

@section('content')
<div class="page-head">
    <div>
        <h1><span class="ico"><i class="bi bi-arrow-left-right"></i></span> Movimiento de stock</h1>
        <p>Historial real de lo que entra y sale del inventario.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="{{ route('stock-movements.export', request()->query()) }}" class="btn btn-outline-secondary"><i class="bi bi-filetype-csv"></i> Exportar</a>
        <a href="{{ route('stock-movements.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Registrar movimiento</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3"><div class="card stat" style="--glow:#10b981">
        <span class="ico g-green"><i class="bi bi-box-arrow-in-down"></i></span>
        <div class="label">Entradas</div><div class="value text-success">+{{ number_format($totals->ins) }}</div>
    </div></div>
    <div class="col-6 col-lg-3"><div class="card stat" style="--glow:#dc2626">
        <span class="ico g-red"><i class="bi bi-box-arrow-up"></i></span>
        <div class="label">Salidas</div><div class="value text-danger">−{{ number_format($totals->outs) }}</div>
    </div></div>
    <div class="col-6 col-lg-3"><div class="card stat" style="--glow:#2563eb">
        <span class="ico g-blue"><i class="bi bi-plus-slash-minus"></i></span>
        <div class="label">Balance neto</div>
        <div class="value">{{ ($totals->ins - $totals->outs) >= 0 ? '+' : '−' }}{{ number_format(abs($totals->ins - $totals->outs)) }}</div>
    </div></div>
    <div class="col-6 col-lg-3"><div class="card stat" style="--glow:#7c3aed">
        <span class="ico g-violet"><i class="bi bi-list-check"></i></span>
        <div class="label">Movimientos</div><div class="value">{{ number_format($totals->total) }}</div>
    </div></div>
</div>

<form method="GET" action="{{ route('stock-movements.index') }}" class="card filter-bar">
    <div class="row g-3 align-items-end">
        <div class="col-md-4">
            <label for="q" class="form-label">Producto</label>
            <div class="input-group">
                <span class="input-group-text" style="background:var(--surface-2);border-color:var(--border);color:var(--muted)"><i class="bi bi-search"></i></span>
                <input id="q" name="q" class="form-control" placeholder="Nombre del producto…" value="{{ request('q') }}">
            </div>
        </div>
        <div class="col-6 col-md-2">
            <label for="type" class="form-label">Tipo</label>
            <select id="type" name="type" class="form-select">
                <option value="">Todos</option>
                <option value="in" @selected(request('type') === 'in')>Entradas</option>
                <option value="out" @selected(request('type') === 'out')>Salidas</option>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label for="from" class="form-label">Desde</label>
            <input id="from" type="date" name="from" class="form-control" value="{{ request('from') }}">
        </div>
        <div class="col-6 col-md-2">
            <label for="to" class="form-label">Hasta</label>
            <input id="to" type="date" name="to" class="form-control" value="{{ request('to') }}">
        </div>
        <div class="col-6 col-md-2 d-flex gap-2">
            <button class="btn btn-primary flex-grow-1"><i class="bi bi-funnel"></i> Filtrar</button>
            <a href="{{ route('stock-movements.index') }}" class="btn btn-outline-secondary" title="Limpiar"><i class="bi bi-x-lg"></i></a>
        </div>
    </div>
</form>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover table-stack">
            <thead>
                <tr><th>Producto</th><th>Tipo</th><th class="text-end">Cantidad</th><th>Stock</th><th>Motivo</th><th>Fecha</th><th>Usuario</th></tr>
            </thead>
            <tbody>
            @forelse ($movements as $m)
                <tr>
                    <td data-label="Producto"><div class="cell">
                        <span class="mv-ico {{ $m->type }}"><i class="bi {{ $m->isEntry() ? 'bi-arrow-down-left' : 'bi-arrow-up-right' }}"></i></span>
                        <div>
                            <strong>{{ $m->product_name }}</strong>
                            @if (! $m->product_id)<small>Producto eliminado</small>
                            @elseif ($m->notes)<small title="{{ $m->notes }}">{{ \Illuminate\Support\Str::limit($m->notes, 38) }}</small>@endif
                        </div>
                    </div></td>
                    <td data-label="Tipo"><span class="pill {{ $m->isEntry() ? 'ok' : 'out' }}">{{ $m->typeLabel() }}</span></td>
                    <td data-label="Cantidad" class="text-end"><span class="qty {{ $m->type }}">{{ $m->isEntry() ? '+' : '−' }}{{ number_format($m->quantity) }}</span></td>
                    <td data-label="Stock"><span class="flow">{{ $m->stock_before }} <i class="bi bi-arrow-right small"></i> <b>{{ $m->stock_after }}</b></span></td>
                    <td data-label="Motivo" class="text-secondary">{{ $m->reason }}</td>
                    <td data-label="Fecha"><div>{{ $m->created_at->format('d/m/Y') }}</div><small class="text-secondary">{{ $m->created_at->format('H:i') }}</small></td>
                    <td data-label="Usuario" class="text-secondary">{{ $m->user->name ?? 'Sistema' }}</td>
                </tr>
            @empty
                <tr><td colspan="7"><div class="empty"><i class="bi bi-arrow-left-right"></i>No hay movimientos con esos filtros.</div></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-2">
    <small class="text-secondary">Mostrando {{ $movements->firstItem() ?? 0 }}–{{ $movements->lastItem() ?? 0 }} de {{ $movements->total() }} movimientos</small>
    {{ $movements->links() }}
</div>
@endsection
