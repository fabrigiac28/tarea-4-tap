@extends('layouts.app')
@section('title', 'Registrar movimiento')

@section('content')
@include('partials.page-header', ['icon' => 'bi-plus-circle', 'title' => 'Registrar movimiento',
    'subtitle' => 'Anota una entrada o salida de stock. El inventario se actualiza al instante.',
    'back' => route('stock-movements.index')])

<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('stock-movements.store') }}" id="mvForm">
            @csrf

            <div class="mb-4">
                <label class="form-label">Tipo de movimiento *</label>
                <div class="seg">
                    <input type="radio" name="type" id="t_in" value="in" @checked(old('type', 'in') === 'in')>
                    <label for="t_in" class="in"><i class="bi bi-box-arrow-in-down"></i> Entrada<small>Ingresa mercadería al inventario</small></label>
                    <input type="radio" name="type" id="t_out" value="out" @checked(old('type') === 'out')>
                    <label for="t_out" class="out"><i class="bi bi-box-arrow-up"></i> Salida<small>Sale mercadería del inventario</small></label>
                </div>
                @error('type')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
            </div>

            <div class="mb-3">
                <label for="product_id" class="form-label">Producto *</label>
                <select id="product_id" name="product_id" required class="form-select @error('product_id') is-invalid @enderror">
                    <option value="">Seleccione...</option>
                    @foreach ($products as $p)
                        <option value="{{ $p->id }}" data-stock="{{ $p->stock }}" @selected(old('product_id', $selected) == $p->id)>
                            {{ $p->name }}{{ $p->sku ? ' · '.$p->sku : '' }} — stock: {{ $p->stock }}
                        </option>
                    @endforeach
                </select>
                @error('product_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="row">
                <div class="col-md-5 mb-3">
                    <label for="quantity" class="form-label">Cantidad *</label>
                    <input id="quantity" type="number" min="1" name="quantity" required value="{{ old('quantity', 1) }}"
                           class="form-control @error('quantity') is-invalid @enderror">
                    @error('quantity')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-7 mb-3">
                    <label for="reason" class="form-label">Motivo *</label>
                    <select id="reason" name="reason" required class="form-select @error('reason') is-invalid @enderror"></select>
                    @error('reason')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
            </div>

            <div class="mb-3">
                <label for="notes" class="form-label">Notas</label>
                <textarea id="notes" name="notes" rows="2" maxlength="500" placeholder="Opcional: N.º de guía, cliente, observaciones…"
                          class="form-control @error('notes') is-invalid @enderror">{{ old('notes') }}</textarea>
                @error('notes')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="preview mb-4" id="preview">Selecciona un producto para ver el resultado.</div>

            <button class="btn btn-primary"><i class="bi bi-save"></i> Registrar movimiento</button>
            <a href="{{ route('stock-movements.index') }}" class="btn btn-outline-secondary">Cancelar</a>
        </form>
    </div></div></div>

    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-lightbulb text-warning"></i> Cómo funciona</h6>
        <ul>
            <li>Cada movimiento guarda el stock <b>antes</b> y <b>después</b>.</li>
            <li>Una salida no puede superar el stock disponible.</li>
            <li>Los movimientos no se editan ni se borran: son el historial real.</li>
            <li>Para corregir un error, registra un movimiento contrario con motivo «Ajuste de inventario».</li>
        </ul>
    </div></div>
</div>
@endsection

@push('scripts')
<script>
(function () {
    const reasons = @json($reasons);
    const oldReason = @json(old('reason'));
    const sel = document.getElementById('reason');
    const prod = document.getElementById('product_id');
    const qty = document.getElementById('quantity');
    const prev = document.getElementById('preview');
    const type = () => document.querySelector('input[name=type]:checked')?.value || 'in';

    function fillReasons(keep) {
        const current = keep ? (sel.value || oldReason) : null;
        sel.innerHTML = '<option value="">Seleccione...</option>' +
            (reasons[type()] || []).map(r => `<option value="${r}" ${r === current ? 'selected' : ''}>${r}</option>`).join('');
    }

    function preview() {
        const opt = prod.options[prod.selectedIndex];
        if (!opt || !opt.dataset.stock) { prev.textContent = 'Selecciona un producto para ver el resultado.'; return; }
        const now = parseInt(opt.dataset.stock, 10), q = parseInt(qty.value, 10) || 0;
        const after = type() === 'in' ? now + q : now - q;
        const bad = after < 0;
        prev.innerHTML = `Stock actual: <b>${now}</b> &nbsp;→&nbsp; Nuevo stock: ` +
            `<span class="big ${bad ? 'text-danger' : (type() === 'in' ? 'text-success' : '')}">${after}</span>` +
            (bad ? ' <span class="text-danger small">· supera el stock disponible</span>' : '');
    }

    document.querySelectorAll('input[name=type]').forEach(r => r.addEventListener('change', () => { fillReasons(false); preview(); }));
    prod.addEventListener('change', preview);
    qty.addEventListener('input', preview);
    fillReasons(true); preview();
})();
</script>
@endpush
