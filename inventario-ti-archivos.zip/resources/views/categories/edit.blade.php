@extends('layouts.app')
@section('title', 'Editar categoría')

@section('content')
@include('partials.page-header', ['icon' => 'bi-pencil-square', 'title' => 'Editar categoría',
    'subtitle' => $category->name, 'back' => route('categories.index')])
<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('categories.update', $category) }}">
            @method('PUT')
            @include('categories._form', ['button' => 'Actualizar categoría'])
        </form>
    </div></div></div>
    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-info-circle text-primary"></i> Información</h6>
        <ul><li>Creada: {{ $category->created_at->format('d/m/Y H:i') }}</li><li>Productos asociados: {{ $category->products()->count() }}</li></ul>
    </div></div>
</div>
@endsection
