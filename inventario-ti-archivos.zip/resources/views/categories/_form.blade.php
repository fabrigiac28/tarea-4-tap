@csrf
<div class="mb-3">
    <label for="name" class="form-label">Nombre *</label>
    <input id="name" name="name" maxlength="100" required
           class="form-control @error('name') is-invalid @enderror"
           value="{{ old('name', $category->name ?? '') }}">
    @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<div class="mb-3">
    <label for="description" class="form-label">Descripción</label>
    <textarea id="description" name="description" rows="3"
              class="form-control @error('description') is-invalid @enderror">{{ old('description', $category->description ?? '') }}</textarea>
    @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<button class="btn btn-primary"><i class="bi bi-save"></i> {{ $button }}</button>
<a href="{{ route('categories.index') }}" class="btn btn-outline-secondary">Cancelar</a>
