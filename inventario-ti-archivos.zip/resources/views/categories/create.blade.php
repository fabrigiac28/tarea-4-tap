@extends('layouts.app')
@section('title', 'Nueva categoría')

@section('content')
@include('partials.page-header', ['icon' => 'bi-plus-circle', 'title' => 'Nueva categoría',
    'subtitle' => 'Registra un grupo de productos.', 'back' => route('categories.index')])
<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('categories.store') }}">
            @include('categories._form', ['button' => 'Guardar categoría'])
        </form>
    </div></div></div>
    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-lightbulb text-warning"></i> Consejos</h6>
        <ul><li>El nombre debe ser único.</li><li>Usa nombres cortos: Laptops, Monitores…</li><li>La descripción es opcional.</li></ul>
    </div></div>
</div>
@endsection
