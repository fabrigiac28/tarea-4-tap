@extends('layouts.app')
@section('title', 'Categorías')

@section('content')
@include('partials.page-header', [
    'icon' => 'bi-diagram-3-fill', 'title' => 'Categorías',
    'subtitle' => 'Organiza el catálogo por tipo de producto.',
    'action' => route('categories.create'), 'actionLabel' => 'Nueva categoría',
])

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover table-stack">
            <thead><tr><th>Categoría</th><th>Descripción</th><th class="text-center">Productos</th><th class="text-end">Acciones</th></tr></thead>
            <tbody>
            @forelse ($categories as $category)
                <tr>
                    <td data-label="Categoría"><div class="cell">
                        <span class="avatar" style="--h:{{ crc32($category->name) % 360 }}">{{ mb_strtoupper(mb_substr($category->name, 0, 1)) }}</span>
                        <strong>{{ $category->name }}</strong>
                    </div></td>
                    <td data-label="Descripción" class="text-secondary">{{ $category->description ?: '—' }}</td>
                    <td data-label="Productos" class="text-center"><span class="pill info plain">{{ $category->products_count }}</span></td>
                    <td data-label="Acciones" class="text-end">
                        <a href="{{ route('categories.edit', $category) }}" class="btn-act edit" title="Editar"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="{{ route('categories.destroy', $category) }}" class="d-inline"
                              data-confirm="¿Eliminar la categoría «{{ $category->name }}»?">
                            @csrf @method('DELETE')
                            <button class="btn-act del" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="4"><div class="empty"><i class="bi bi-diagram-3"></i>No hay categorías registradas.</div></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">{{ $categories->links() }}</div>
@endsection
