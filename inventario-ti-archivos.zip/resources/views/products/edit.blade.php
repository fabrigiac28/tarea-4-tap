@extends('layouts.app')
@section('title', 'Editar producto')

@section('content')
@include('partials.page-header', ['icon' => 'bi-pencil-square', 'title' => 'Editar producto',
    'subtitle' => $product->name, 'back' => route('products.index')])
<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('products.update', $product) }}">
            @method('PUT')
            @include('products._form', ['button' => 'Actualizar producto'])
        </form>
    </div></div></div>
    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-info-circle text-primary"></i> Información</h6>
        <ul>
            <li>Creado: {{ $product->created_at->format('d/m/Y H:i') }}</li>
            <li>Última edición: {{ $product->updated_at->diffForHumans() }}</li>
            <li>Valor en stock: S/ {{ number_format($product->price * $product->stock, 2) }}</li>
        </ul>
    </div></div>
</div>
@endsection
