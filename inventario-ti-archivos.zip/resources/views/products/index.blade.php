@extends('layouts.app')
@section('title', 'Productos')

@section('content')
@include('partials.page-header', [
    'icon' => 'bi-cpu-fill', 'title' => 'Productos',
    'subtitle' => 'Catálogo completo con categoría, proveedor y estado de stock.',
    'action' => route('products.create'), 'actionLabel' => 'Nuevo producto',
])

<form method="GET" action="{{ route('products.index') }}" class="card filter-bar">
    <div class="row g-3 align-items-end">
        <div class="col-md-5">
            <label for="q" class="form-label">Buscar</label>
            <div class="input-group">
                <span class="input-group-text" style="background:var(--surface-2);border-color:var(--border);color:var(--muted)"><i class="bi bi-search"></i></span>
                <input id="q" name="q" class="form-control" placeholder="Nombre o SKU…" value="{{ request('q') }}">
            </div>
        </div>
        <div class="col-md-3">
            <label for="category" class="form-label">Categoría</label>
            <select id="category" name="category" class="form-select">
                <option value="">Todas</option>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" @selected(request('category') == $category->id)>{{ $category->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-2">
            <div class="form-check form-switch mb-2">
                <input class="form-check-input" type="checkbox" role="switch" name="low" value="1" id="low" @checked(request()->boolean('low'))>
                <label class="form-check-label small" for="low">Solo stock bajo</label>
            </div>
        </div>
        <div class="col-md-2 d-flex gap-2">
            <button class="btn btn-primary flex-grow-1"><i class="bi bi-funnel"></i> Filtrar</button>
            <a href="{{ route('products.index') }}" class="btn btn-outline-secondary" title="Limpiar"><i class="bi bi-x-lg"></i></a>
        </div>
    </div>
</form>

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover table-stack">
            <thead>
                <tr><th>Producto</th><th>SKU</th><th>Categoría</th><th>Proveedor</th>
                    <th class="text-end">Precio</th><th>Stock</th><th class="text-end">Acciones</th></tr>
            </thead>
            <tbody>
            @forelse ($products as $product)
                @php $status = $product->stockStatus(); @endphp
                <tr>
                    <td data-label="Producto"><div class="cell">
                        <span class="avatar" style="--h:{{ crc32($product->name) % 360 }}">{{ mb_strtoupper(mb_substr($product->name, 0, 1)) }}</span>
                        <strong>{{ $product->name }}</strong>
                    </div></td>
                    <td data-label="SKU">@if ($product->sku)<span class="sku">{{ $product->sku }}</span>@else<span class="text-secondary">—</span>@endif</td>
                    <td data-label="Categoría"><span class="pill info plain">{{ $product->category->name }}</span></td>
                    <td data-label="Proveedor" class="text-secondary">{{ $product->supplier->name }}</td>
                    <td data-label="Precio" class="text-end fw-semibold">S/ {{ number_format($product->price, 2) }}</td>
                    <td data-label="Stock">
                        <span class="pill {{ $status }}">
                            {{ $status === 'out' ? 'Agotado' : ($status === 'low' ? 'Stock bajo' : 'Disponible') }} · {{ $product->stock }}
                        </span>
                        <div class="stockbar"><span class="{{ $status }}" style="width:{{ max(4, min(100, $product->stock * 2)) }}%"></span></div>
                    </td>
                    <td data-label="Acciones" class="text-end">
                        <a href="{{ route('stock-movements.create', ['product' => $product->id]) }}" class="btn-act move" title="Registrar movimiento"><i class="bi bi-arrow-left-right"></i></a>
                        <a href="{{ route('products.edit', $product) }}" class="btn-act edit" title="Editar"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="{{ route('products.destroy', $product) }}" class="d-inline"
                              data-confirm="¿Eliminar el producto «{{ $product->name }}»?">
                            @csrf @method('DELETE')
                            <button class="btn-act del" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7"><div class="empty"><i class="bi bi-search"></i>No hay productos que coincidan con la búsqueda.</div></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-2">
    <small class="text-secondary">Mostrando {{ $products->firstItem() ?? 0 }}–{{ $products->lastItem() ?? 0 }} de {{ $products->total() }} productos</small>
    {{ $products->links() }}
</div>
@endsection
