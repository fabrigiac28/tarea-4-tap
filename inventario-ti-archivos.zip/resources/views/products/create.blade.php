@extends('layouts.app')
@section('title', 'Nuevo producto')

@section('content')
@include('partials.page-header', ['icon' => 'bi-plus-circle', 'title' => 'Nuevo producto',
    'subtitle' => 'Registra un producto con su categoría y proveedor.', 'back' => route('products.index')])
<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('products.store') }}">
            @include('products._form', ['button' => 'Guardar producto'])
        </form>
    </div></div></div>
    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-lightbulb text-warning"></i> Consejos</h6>
        <ul>
            <li>El SKU es opcional, pero no puede repetirse.</li>
            <li>Con stock menor a {{ \App\Models\Product::LOW_STOCK }} se marcará como <b>Stock bajo</b>.</li>
            <li>Si no ves la categoría o el proveedor, regístralos primero.</li>
        </ul>
    </div></div>
</div>
@endsection
