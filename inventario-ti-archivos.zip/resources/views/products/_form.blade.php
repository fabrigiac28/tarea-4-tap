@csrf
<div class="row">
    <div class="col-md-4 mb-3">
        <label for="sku" class="form-label">SKU</label>
        <input id="sku" name="sku" maxlength="50"
               class="form-control @error('sku') is-invalid @enderror"
               value="{{ old('sku', $product->sku ?? '') }}">
        @error('sku')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-8 mb-3">
        <label for="name" class="form-label">Nombre *</label>
        <input id="name" name="name" maxlength="150" required
               class="form-control @error('name') is-invalid @enderror"
               value="{{ old('name', $product->name ?? '') }}">
        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="category_id" class="form-label">Categoría *</label>
        <select id="category_id" name="category_id" required class="form-select @error('category_id') is-invalid @enderror">
            <option value="">Seleccione...</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}" @selected(old('category_id', $product->category_id ?? '') == $category->id)>{{ $category->name }}</option>
            @endforeach
        </select>
        @error('category_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="supplier_id" class="form-label">Proveedor *</label>
        <select id="supplier_id" name="supplier_id" required class="form-select @error('supplier_id') is-invalid @enderror">
            <option value="">Seleccione...</option>
            @foreach ($suppliers as $supplier)
                <option value="{{ $supplier->id }}" @selected(old('supplier_id', $product->supplier_id ?? '') == $supplier->id)>{{ $supplier->name }}</option>
            @endforeach
        </select>
        @error('supplier_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="price" class="form-label">Precio (S/) *</label>
        <input id="price" type="number" step="0.01" min="0" name="price" required
               class="form-control @error('price') is-invalid @enderror"
               value="{{ old('price', $product->price ?? '') }}">
        @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="stock" class="form-label">Stock *</label>
        <input id="stock" type="number" min="0" name="stock" required
               class="form-control @error('stock') is-invalid @enderror"
               value="{{ old('stock', $product->stock ?? 0) }}">
        @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
        @isset($product)<div class="form-text">Si cambias el stock aquí se registra un movimiento «Ajuste manual». Para entradas/salidas usa <a href="{{ route('stock-movements.create', ['product' => $product->id]) }}">Movimiento de stock</a>.</div>@endisset
    </div>
</div>

<div class="mb-3">
    <label for="description" class="form-label">Descripción</label>
    <textarea id="description" name="description" rows="3"
              class="form-control @error('description') is-invalid @enderror">{{ old('description', $product->description ?? '') }}</textarea>
    @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>

<button class="btn btn-primary"><i class="bi bi-save"></i> {{ $button }}</button>
<a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Cancelar</a>
