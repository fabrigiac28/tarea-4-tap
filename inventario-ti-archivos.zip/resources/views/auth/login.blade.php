<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Iniciar sesión · Inventario TI</title>
    <script>
        try { document.documentElement.setAttribute('data-bs-theme', localStorage.getItem('theme') || 'dark'); } catch (e) {}
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="{{ asset('css/inventario.css') }}" rel="stylesheet">
</head>
<body>
<div class="auth">

    <section class="auth-aside">
        <div class="d-flex align-items-center gap-3">
            <span class="brand-logo"><i class="bi bi-hexagon-fill"></i></span>
            <div class="brand-name text-white">Inventario TI<small>SENATI · Escuela de Tecnologías de la Información</small></div>
        </div>

        <div>
            <h2>Controla tu inventario<br>con precisión.</h2>
            <p class="lead">Productos, proveedores y cada entrada y salida de stock, en un solo panel.</p>

            <div class="features">
                <div class="feature"><span class="fi"><i class="bi bi-arrow-left-right"></i></span>
                    <div><b>Movimientos en tiempo real</b><span>Historial completo de lo que entra y sale.</span></div></div>
                <div class="feature"><span class="fi"><i class="bi bi-bar-chart-line"></i></span>
                    <div><b>Métricas y alertas</b><span>Gráficos y avisos de stock bajo.</span></div></div>
                <div class="feature"><span class="fi"><i class="bi bi-shield-lock"></i></span>
                    <div><b>Acceso protegido</b><span>Solo usuarios autorizados.</span></div></div>
            </div>
        </div>

        <small class="text-white-50 d-none d-lg-block">© {{ date('Y') }} SENATI · Marco de Desarrollo para Proyectos</small>
    </section>

    <section class="auth-main">
        <button class="icon-btn auth-theme" id="themeToggle" type="button" aria-label="Cambiar tema"></button>

        <div class="auth-card">
            <h1>Bienvenido de nuevo</h1>
            <p class="text-secondary mb-4">Ingresa con tu cuenta para acceder al sistema.</p>

            @if ($errors->any())
                <div class="alert alert-danger d-flex gap-2 align-items-start py-2" role="alert">
                    <i class="bi bi-exclamation-octagon mt-1"></i>
                    <div class="small">{{ $errors->first() }}</div>
                </div>
            @endif

            <form method="POST" action="{{ route('login.attempt') }}" id="loginForm" novalidate>
                @csrf
                <div class="mb-3">
                    <label for="email" class="form-label">Correo electrónico</label>
                    <div class="input-icon">
                        <i class="bi bi-envelope lead-i"></i>
                        <input id="email" type="email" name="email" value="{{ old('email') }}"
                               class="form-control @error('email') is-invalid @enderror"
                               placeholder="usuario@senati.pe" autocomplete="username" autofocus required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <div class="input-icon">
                        <i class="bi bi-lock lead-i"></i>
                        <input id="password" type="password" name="password"
                               class="form-control @error('password') is-invalid @enderror"
                               placeholder="••••••••" autocomplete="current-password" required>
                        <button type="button" class="eye" id="togglePass" aria-label="Mostrar contraseña"><i class="bi bi-eye"></i></button>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember">
                        <label class="form-check-label small" for="remember">Mantener sesión iniciada</label>
                    </div>
                </div>

                <button class="btn btn-primary btn-lg-tech w-100" id="loginBtn">
                    <span class="btn-text"><i class="bi bi-box-arrow-in-right me-1"></i> Iniciar sesión</span>
                    <span class="spinner-border spinner-border-sm d-none" aria-hidden="true"></span>
                </button>
            </form>

            @if (app()->environment('local'))
                <div class="demo-box mt-4">
                    <div class="fw-bold mb-1"><i class="bi bi-info-circle text-primary"></i> Cuenta de práctica</div>
                    <div>Correo: <span class="mono">admin@senati.pe</span></div>
                    <div>Contraseña: <span class="mono">Admin12345</span></div>
                </div>
            @endif
        </div>
    </section>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('js/inventario.js') }}"></script>
<script>
    const pass = document.getElementById('password');
    document.getElementById('togglePass').addEventListener('click', function () {
        const show = pass.type === 'password';
        pass.type = show ? 'text' : 'password';
        this.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
    });
    document.getElementById('loginForm').addEventListener('submit', function () {
        const b = document.getElementById('loginBtn');
        b.disabled = true;
        b.querySelector('.btn-text').classList.add('d-none');
        b.querySelector('.spinner-border').classList.remove('d-none');
    });
</script>
</body>
</html>
