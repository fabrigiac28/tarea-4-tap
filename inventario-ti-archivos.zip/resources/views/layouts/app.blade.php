<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#0a1020">
    <title>@yield('title', 'Inicio') · Inventario TI</title>
    <script>
        try { document.documentElement.setAttribute('data-bs-theme', localStorage.getItem('theme') || 'dark'); } catch (e) {}
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="{{ asset('css/inventario.css') }}" rel="stylesheet">
    @stack('head')
</head>
<body>
<div class="app">

    {{-- ========== Barra lateral ========== --}}
    <aside class="sidebar" id="sidebar">
        <a href="{{ route('dashboard') }}" class="brand">
            <span class="brand-logo"><i class="bi bi-hexagon-fill"></i></span>
            <span class="brand-name">Inventario TI<small>SENATI · Laravel</small></span>
        </a>

        <div class="nav-label">General</div>
        <a class="side-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
            <i class="bi bi-grid-1x2-fill"></i> Panel de control
        </a>

        <div class="nav-label">Gestión</div>
        <a class="side-link {{ request()->routeIs('products.*') ? 'active' : '' }}" href="{{ route('products.index') }}">
            <i class="bi bi-cpu-fill"></i> Productos
        </a>
        <a class="side-link {{ request()->routeIs('stock-movements.*') ? 'active' : '' }}" href="{{ route('stock-movements.index') }}">
            <i class="bi bi-arrow-left-right"></i> Movimiento de stock
        </a>
        <a class="side-link {{ request()->routeIs('categories.*') ? 'active' : '' }}" href="{{ route('categories.index') }}">
            <i class="bi bi-diagram-3-fill"></i> Categorías
        </a>
        <a class="side-link {{ request()->routeIs('suppliers.*') ? 'active' : '' }}" href="{{ route('suppliers.index') }}">
            <i class="bi bi-truck"></i> Proveedores
        </a>

        <div class="nav-label">Accesos rápidos</div>
        <a class="side-link" href="{{ route('stock-movements.create') }}"><i class="bi bi-plus-circle"></i> Registrar movimiento</a>
        <a class="side-link" href="{{ route('products.index', ['low' => 1]) }}"><i class="bi bi-exclamation-triangle"></i> Stock bajo</a>

        <div class="side-foot">
            <div class="fw-semibold text-white mb-1"><span class="dot"></span>Sistema activo</div>
            Laravel {{ app()->version() }} · PHP {{ PHP_VERSION }}
        </div>
    </aside>
    <div class="backdrop" id="backdrop"></div>

    {{-- ========== Contenido ========== --}}
    <div class="main">
        <header class="topbar">
            <button class="icon-btn d-lg-none" id="menuToggle" aria-label="Abrir menú"><i class="bi bi-list fs-5"></i></button>
            <div class="crumb text-truncate">Inventario <i class="bi bi-chevron-right small"></i> <b>@yield('title', 'Inicio')</b></div>
            <div class="ms-auto d-flex align-items-center gap-2">
                <button class="icon-btn" id="themeToggle" aria-label="Cambiar tema"></button>

                @auth
                <div class="dropdown">
                    <button class="user-chip dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="av">{{ mb_strtoupper(mb_substr(auth()->user()->name, 0, 1)) }}</span>
                        <span class="d-none d-sm-inline">{{ \Illuminate\Support\Str::words(auth()->user()->name, 2, '') }}</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li class="dropdown-header">
                            <div class="fw-bold text-body">{{ auth()->user()->name }}</div>
                            <div class="small text-secondary text-break">{{ auth()->user()->email }}</div>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión</button>
                            </form>
                        </li>
                    </ul>
                </div>
                @endauth
            </div>
        </header>

        <main class="content">
            @include('partials.alerts')
            @yield('content')
        </main>

        <footer class="footer">
            © {{ date('Y') }} Inventario de accesorios informáticos · Escuela de Tecnologías de la Información · SENATI
        </footer>
    </div>
</div>

{{-- Modal de confirmación --}}
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center p-4">
                <div class="pill out plain mb-3" style="font-size:1.6rem;padding:14px 18px"><i class="bi bi-trash3"></i></div>
                <h5 class="fw-bold">Confirmar eliminación</h5>
                <p class="text-secondary mb-4" id="confirmText">¿Seguro que deseas eliminar este registro?</p>
                <div class="d-flex gap-2 justify-content-center">
                    <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button class="btn btn-danger" id="confirmOk"><i class="bi bi-trash"></i> Sí, eliminar</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('js/inventario.js') }}"></script>
@stack('scripts')
</body>
</html>
