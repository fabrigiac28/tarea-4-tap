<div class="toast-wrap">
    @if (session('success'))
        <div class="toast toast-tech" role="alert">
            <div class="d-flex align-items-center gap-3 p-3">
                <span class="ico g-green"><i class="bi bi-check-lg"></i></span>
                <div class="flex-grow-1"><div class="fw-bold">Operación exitosa</div><div class="small text-secondary">{{ session('success') }}</div></div>
                <button class="btn-close" data-bs-dismiss="toast"></button>
            </div>
        </div>
    @endif
    @if (session('error'))
        <div class="toast toast-tech error" role="alert">
            <div class="d-flex align-items-center gap-3 p-3">
                <span class="ico g-red"><i class="bi bi-x-lg"></i></span>
                <div class="flex-grow-1"><div class="fw-bold">No se pudo completar</div><div class="small text-secondary">{{ session('error') }}</div></div>
                <button class="btn-close" data-bs-dismiss="toast"></button>
            </div>
        </div>
    @endif
</div>

@if ($errors->any())
    <div class="card mb-4 p-3 d-flex flex-row align-items-center gap-3" style="border-left:4px solid var(--danger)">
        <span class="pill out plain" style="font-size:1.2rem"><i class="bi bi-exclamation-octagon"></i></span>
        <div><div class="fw-bold">Revisa el formulario</div>
        <div class="small text-secondary">Hay {{ $errors->count() }} error(es) de validación marcados en rojo.</div></div>
    </div>
@endif
