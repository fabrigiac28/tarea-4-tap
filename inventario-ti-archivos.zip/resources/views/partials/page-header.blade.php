<div class="page-head">
    <div>
        <h1><span class="ico"><i class="bi {{ $icon ?? 'bi-grid' }}"></i></span> {{ $title }}</h1>
        @isset($subtitle)<p>{{ $subtitle }}</p>@endisset
    </div>
    <div class="d-flex gap-2">
        @isset($back)<a href="{{ $back }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Volver</a>@endisset
        @isset($action)<a href="{{ $action }}" class="btn btn-primary"><i class="bi bi-plus-lg"></i> {{ $actionLabel }}</a>@endisset
    </div>
</div>
