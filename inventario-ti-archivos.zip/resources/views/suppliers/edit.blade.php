@extends('layouts.app')
@section('title', 'Editar proveedor')

@section('content')
@include('partials.page-header', ['icon' => 'bi-pencil-square', 'title' => 'Editar proveedor',
    'subtitle' => $supplier->name, 'back' => route('suppliers.index')])
<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('suppliers.update', $supplier) }}">
            @method('PUT')
            @include('suppliers._form', ['button' => 'Actualizar proveedor'])
        </form>
    </div></div></div>
    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-info-circle text-primary"></i> Información</h6>
        <ul><li>Registrado: {{ $supplier->created_at->format('d/m/Y H:i') }}</li><li>Productos suministrados: {{ $supplier->products()->count() }}</li></ul>
    </div></div>
</div>
@endsection
