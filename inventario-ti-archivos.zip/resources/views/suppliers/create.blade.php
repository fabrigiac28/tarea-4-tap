@extends('layouts.app')
@section('title', 'Nuevo proveedor')

@section('content')
@include('partials.page-header', ['icon' => 'bi-plus-circle', 'title' => 'Nuevo proveedor',
    'subtitle' => 'Registra una empresa proveedora.', 'back' => route('suppliers.index')])
<div class="row g-3">
    <div class="col-lg-8"><div class="card"><div class="card-body p-4">
        <form method="POST" action="{{ route('suppliers.store') }}">
            @include('suppliers._form', ['button' => 'Guardar proveedor'])
        </form>
    </div></div></div>
    <div class="col-lg-4"><div class="card tip">
        <h6><i class="bi bi-lightbulb text-warning"></i> Consejos</h6>
        <ul><li>Solo el nombre es obligatorio.</li><li>El correo debe tener formato válido.</li><li>Agrega un teléfono para contacto rápido.</li></ul>
    </div></div>
</div>
@endsection
