@extends('layouts.app')
@section('title', 'Proveedores')

@section('content')
@include('partials.page-header', [
    'icon' => 'bi-truck', 'title' => 'Proveedores',
    'subtitle' => 'Empresas que abastecen tu inventario.',
    'action' => route('suppliers.create'), 'actionLabel' => 'Nuevo proveedor',
])

<div class="card table-card">
    <div class="table-responsive">
        <table class="table table-hover table-stack">
            <thead><tr><th>Proveedor</th><th>Contacto</th><th>Dirección</th><th class="text-center">Productos</th><th class="text-end">Acciones</th></tr></thead>
            <tbody>
            @forelse ($suppliers as $supplier)
                <tr>
                    <td data-label="Proveedor"><div class="cell">
                        <span class="avatar" style="--h:{{ crc32($supplier->name) % 360 }}">{{ mb_strtoupper(mb_substr($supplier->name, 0, 1)) }}</span>
                        <strong>{{ $supplier->name }}</strong>
                    </div></td>
                    <td data-label="Contacto">
                        @if ($supplier->email)<div><i class="bi bi-envelope text-secondary"></i> {{ $supplier->email }}</div>@endif
                        @if ($supplier->phone)<div class="small text-secondary"><i class="bi bi-telephone"></i> {{ $supplier->phone }}</div>@endif
                        @if (! $supplier->email && ! $supplier->phone)<span class="text-secondary">—</span>@endif
                    </td>
                    <td data-label="Dirección" class="text-secondary">{{ $supplier->address ?: '—' }}</td>
                    <td data-label="Productos" class="text-center"><span class="pill info plain">{{ $supplier->products_count }}</span></td>
                    <td data-label="Acciones" class="text-end">
                        <a href="{{ route('suppliers.edit', $supplier) }}" class="btn-act edit" title="Editar"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="{{ route('suppliers.destroy', $supplier) }}" class="d-inline"
                              data-confirm="¿Eliminar al proveedor «{{ $supplier->name }}»?">
                            @csrf @method('DELETE')
                            <button class="btn-act del" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5"><div class="empty"><i class="bi bi-truck"></i>No hay proveedores registrados.</div></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">{{ $suppliers->links() }}</div>
@endsection
