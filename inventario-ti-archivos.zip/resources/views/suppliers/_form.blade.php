@csrf
<div class="mb-3">
    <label for="name" class="form-label">Nombre *</label>
    <input id="name" name="name" maxlength="150" required
           class="form-control @error('name') is-invalid @enderror"
           value="{{ old('name', $supplier->name ?? '') }}">
    @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<div class="row">
    <div class="col-md-6 mb-3">
        <label for="email" class="form-label">Email</label>
        <input id="email" type="email" name="email" maxlength="255"
               class="form-control @error('email') is-invalid @enderror"
               value="{{ old('email', $supplier->email ?? '') }}">
        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="phone" class="form-label">Teléfono</label>
        <input id="phone" name="phone" maxlength="30"
               class="form-control @error('phone') is-invalid @enderror"
               value="{{ old('phone', $supplier->phone ?? '') }}">
        @error('phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>
<div class="mb-3">
    <label for="address" class="form-label">Dirección</label>
    <input id="address" name="address" maxlength="255"
           class="form-control @error('address') is-invalid @enderror"
           value="{{ old('address', $supplier->address ?? '') }}">
    @error('address')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<button class="btn btn-primary"><i class="bi bi-save"></i> {{ $button }}</button>
<a href="{{ route('suppliers.index') }}" class="btn btn-outline-secondary">Cancelar</a>
