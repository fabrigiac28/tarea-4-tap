@extends('layouts.app')
@section('title', 'Panel de control')

@section('content')
<div class="hero">
    <h2>Hola, {{ \Illuminate\Support\Str::words(auth()->user()->name, 1, '') }} 👋</h2>
    <p>{{ now()->translatedFormat('l d \d\e F, Y') }} · Controla productos, proveedores y movimientos de stock.</p>
    <a href="{{ route('stock-movements.create') }}" class="btn btn-hero"><i class="bi bi-arrow-left-right"></i> Registrar movimiento</a>
    <a href="{{ route('products.create') }}" class="btn btn-ghost"><i class="bi bi-plus-lg"></i> Nuevo producto</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-4 col-xl-2"><div class="card stat" style="--glow:#2563eb">
        <span class="ico g-blue"><i class="bi bi-cpu"></i></span>
        <div class="label">Productos</div><div class="value">{{ $stats['products'] }}</div></div></div>
    <div class="col-6 col-lg-4 col-xl-2"><div class="card stat" style="--glow:#7c3aed">
        <span class="ico g-violet"><i class="bi bi-diagram-3"></i></span>
        <div class="label">Categorías</div><div class="value">{{ $stats['categories'] }}</div></div></div>
    <div class="col-6 col-lg-4 col-xl-2"><div class="card stat" style="--glow:#0891b2">
        <span class="ico g-cyan"><i class="bi bi-truck"></i></span>
        <div class="label">Proveedores</div><div class="value">{{ $stats['suppliers'] }}</div></div></div>
    <div class="col-6 col-lg-4 col-xl-2"><div class="card stat" style="--glow:#dc2626">
        <span class="ico g-red"><i class="bi bi-exclamation-triangle"></i></span>
        <div class="label">Stock bajo</div><div class="value">{{ $stats['low_stock'] }}</div></div></div>
    <div class="col-6 col-lg-4 col-xl-2"><div class="card stat" style="--glow:#10b981">
        <span class="ico g-green"><i class="bi bi-box-arrow-in-down"></i></span>
        <div class="label">Entradas 7d</div><div class="value text-success">+{{ number_format($stats['ins_week']) }}</div></div></div>
    <div class="col-6 col-lg-4 col-xl-2"><div class="card stat" style="--glow:#dc2626">
        <span class="ico g-red"><i class="bi bi-box-arrow-up"></i></span>
        <div class="label">Salidas 7d</div><div class="value text-danger">−{{ number_format($stats['outs_week']) }}</div></div></div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-4">
        <div class="card h-100"><div class="card-body">
            <div class="text-uppercase small text-secondary fw-semibold" style="letter-spacing:.08em">Valor del inventario</div>
            <div class="display-6 fw-bold mt-1" style="letter-spacing:-.03em">S/ {{ number_format($stats['value'], 2) }}</div>
            <hr style="border-color:var(--border)">
            <div class="small text-secondary mb-2">Productos por categoría</div>
            <div class="chart-box"><canvas id="chartDonut"></canvas></div>
        </div></div>
    </div>
    <div class="col-lg-8">
        <div class="card h-100"><div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                <h6 class="panel-title">Entradas vs. salidas · últimos 7 días</h6>
                <a href="{{ route('stock-movements.index') }}" class="btn btn-sm btn-outline-secondary">Ver historial</a>
            </div>
            <div class="chart-box" style="height:330px"><canvas id="chartMoves"></canvas></div>
        </div></div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card table-card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-exclamation-triangle text-warning"></i> Reposición necesaria (&lt; {{ \App\Models\Product::LOW_STOCK }})</span>
                <a href="{{ route('products.index', ['low' => 1]) }}" class="btn btn-sm btn-outline-secondary">Ver todos</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover table-stack">
                    <thead><tr><th>Producto</th><th>Proveedor</th><th class="text-end">Stock</th><th class="text-end">Acciones</th></tr></thead>
                    <tbody>
                    @forelse ($lowStock as $product)
                        <tr>
                            <td data-label="Producto"><div class="cell">
                                <span class="avatar" style="--h:{{ crc32($product->name) % 360 }}">{{ mb_strtoupper(mb_substr($product->name, 0, 1)) }}</span>
                                <div>{{ $product->name }}<small>{{ $product->category->name }}</small></div>
                            </div></td>
                            <td data-label="Proveedor" class="text-secondary">{{ $product->supplier->name }}</td>
                            <td data-label="Stock" class="text-end"><span class="pill {{ $product->stockStatus() }}">{{ $product->stock === 0 ? 'Agotado' : $product->stock . ' u.' }}</span></td>
                            <td data-label="Acciones" class="text-end">
                                <a href="{{ route('stock-movements.create', ['product' => $product->id]) }}" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Reponer</a>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4"><div class="empty"><i class="bi bi-shield-check"></i>Todo en orden: sin productos con stock bajo.</div></td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-activity text-primary"></i> Últimos movimientos</span>
                <a href="{{ route('stock-movements.index') }}" class="btn btn-sm btn-outline-secondary">Ver todos</a>
            </div>
            @forelse ($latestMovements as $m)
                <div class="list-row">
                    <div class="cell">
                        <span class="mv-ico {{ $m->type }}"><i class="bi {{ $m->isEntry() ? 'bi-arrow-down-left' : 'bi-arrow-up-right' }}"></i></span>
                        <div>{{ $m->product_name }}<small>{{ $m->reason }} · {{ $m->created_at->diffForHumans() }}</small></div>
                    </div>
                    <span class="qty {{ $m->type }}">{{ $m->isEntry() ? '+' : '−' }}{{ $m->quantity }}</span>
                </div>
            @empty
                <div class="empty"><i class="bi bi-inbox"></i>Aún no hay movimientos.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function () {
    const data = @json($chart);
    const palette = ['#2563eb', '#06b6d4', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];
    const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
    Chart.defaults.font.family = "'Inter', sans-serif";

    const donut = new Chart(document.getElementById('chartDonut'), {
        type: 'doughnut',
        data: { labels: data.cats, datasets: [{ data: data.products, backgroundColor: palette, borderWidth: 0, hoverOffset: 6 }] },
        options: { maintainAspectRatio: false, cutout: '68%', plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } } }
    });

    const moves = new Chart(document.getElementById('chartMoves'), {
        type: 'bar',
        data: { labels: data.days, datasets: [
            { label: 'Entradas', data: data.in,  backgroundColor: '#10b981', borderRadius: 8, maxBarThickness: 34 },
            { label: 'Salidas',  data: data.out, backgroundColor: '#ef4444', borderRadius: 8, maxBarThickness: 34 }
        ] },
        options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
                   plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } },
                   scales: { y: { beginAtZero: true, ticks: { precision: 0 }, grid: {} }, x: { grid: { display: false } } } }
    });

    function paint() {
        const muted = css('--muted'), border = css('--border');
        Chart.defaults.color = muted;
        donut.options.plugins.legend.labels.color = muted;
        moves.options.plugins.legend.labels.color = muted;
        moves.options.scales.y.grid.color = border;
        moves.options.scales.x.ticks.color = muted;
        moves.options.scales.y.ticks.color = muted;
        donut.update(); moves.update();
    }
    paint();
    window.addEventListener('themechange', paint);
})();
</script>
@endpush
