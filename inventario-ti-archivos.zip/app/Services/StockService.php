<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockMovement;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Único punto donde cambia el stock: actualiza el producto Y deja el
 * registro del movimiento, dentro de una transacción.
 */
class StockService
{
    public function record(
        Product $product,
        string $type,
        int $quantity,
        string $reason,
        ?string $notes = null,
        ?Carbon $at = null
    ): StockMovement {
        return DB::transaction(function () use ($product, $type, $quantity, $reason, $notes, $at) {
            $locked = Product::whereKey($product->getKey())->lockForUpdate()->firstOrFail();

            $before = (int) $locked->stock;
            $after  = $type === StockMovement::IN ? $before + $quantity : $before - $quantity;

            if ($after < 0) {
                throw ValidationException::withMessages([
                    'quantity' => "Stock insuficiente: solo hay {$before} unidad(es) disponibles.",
                ]);
            }

            $locked->update(['stock' => $after]);
            $product->stock = $after; // mantiene sincronizada la instancia del llamador

            $movement = new StockMovement([
                'product_id'   => $locked->id,
                'product_name' => $locked->name,
                'user_id'      => auth()->id(),
                'type'         => $type,
                'quantity'     => $quantity,
                'stock_before' => $before,
                'stock_after'  => $after,
                'reason'       => $reason,
                'notes'        => $notes,
            ]);

            if ($at) {
                $movement->created_at = $at;
                $movement->updated_at = $at;
            }

            $movement->save();

            return $movement;
        });
    }
}
