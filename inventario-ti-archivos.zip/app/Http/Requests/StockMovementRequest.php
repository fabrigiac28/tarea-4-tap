<?php

namespace App\Http\Requests;

use App\Models\StockMovement;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StockMovementRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'product_id' => ['required', 'exists:products,id'],
            'type'       => ['required', Rule::in([StockMovement::IN, StockMovement::OUT])],
            'quantity'   => ['required', 'integer', 'min:1', 'max:1000000'],
            'reason'     => ['required', Rule::in(StockMovement::reasonsFor($this->input('type')))],
            'notes'      => ['nullable', 'string', 'max:500'],
        ];
    }
}
