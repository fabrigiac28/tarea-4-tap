<?php

namespace App\Http\Controllers;

use App\Http\Requests\StockMovementRequest;
use App\Models\Product;
use App\Models\StockMovement;
use App\Services\StockService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class StockMovementController extends Controller
{
    public function index(Request $request)
    {
        $request->validate([
            'q'    => ['nullable', 'string', 'max:100'],
            'type' => ['nullable', 'in:in,out'],
            'from' => ['nullable', 'date'],
            'to'   => ['nullable', 'date'],
        ]);

        $base = $this->filtered($request);

        $totals = (clone $base)->selectRaw(
            "COALESCE(SUM(CASE WHEN type = 'in'  THEN quantity END), 0) AS ins,
             COALESCE(SUM(CASE WHEN type = 'out' THEN quantity END), 0) AS outs,
             COUNT(*) AS total"
        )->first();

        $movements = $base->with(['product', 'user'])
            ->latest()->latest('id')
            ->paginate(15)
            ->withQueryString();

        return view('stock-movements.index', compact('movements', 'totals'));
    }

    public function create(Request $request)
    {
        $products = Product::orderBy('name')->get(['id', 'name', 'sku', 'stock']);

        return view('stock-movements.create', [
            'products'   => $products,
            'reasons'    => StockMovement::REASONS,
            'selected'   => $request->query('product'),
        ]);
    }

    public function store(StockMovementRequest $request, StockService $stock)
    {
        $data    = $request->validated();
        $product = Product::findOrFail($data['product_id']);

        $stock->record($product, $data['type'], (int) $data['quantity'], $data['reason'], $data['notes'] ?? null);

        $verb = $data['type'] === StockMovement::IN ? 'Entrada' : 'Salida';

        return redirect()->route('stock-movements.index')
            ->with('success', "{$verb} registrada: {$data['quantity']} u. de {$product->name}. Nuevo stock: {$product->stock}.");
    }

    public function export(Request $request)
    {
        $rows = $this->filtered($request)->with('user')->latest()->latest('id')->get();

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // BOM para que Excel respete las tildes
            fputcsv($out, ['Fecha', 'Producto', 'Tipo', 'Cantidad', 'Stock anterior', 'Stock posterior', 'Motivo', 'Usuario', 'Notas']);
            foreach ($rows as $m) {
                fputcsv($out, [
                    $m->created_at->format('Y-m-d H:i'), $m->product_name, $m->typeLabel(), $m->quantity,
                    $m->stock_before, $m->stock_after, $m->reason, $m->user->name ?? 'Sistema', $m->notes,
                ]);
            }
            fclose($out);
        }, 'movimientos-stock-' . now()->format('Ymd-His') . '.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    private function filtered(Request $request): Builder
    {
        return StockMovement::query()
            ->when($request->filled('q'), fn ($q) => $q->where('product_name', 'like', '%' . $request->query('q') . '%'))
            ->when($request->filled('type'), fn ($q) => $q->where('type', $request->query('type')))
            ->when($request->filled('from'), fn ($q) => $q->whereDate('created_at', '>=', $request->query('from')))
            ->when($request->filled('to'), fn ($q) => $q->whereDate('created_at', '<=', $request->query('to')));
    }
}
