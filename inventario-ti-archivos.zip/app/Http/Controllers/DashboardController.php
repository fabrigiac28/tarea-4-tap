<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function __invoke()
    {
        // Últimos 7 días (hoy incluido), del más antiguo al más reciente
        $days  = collect(range(6, 0))->map(fn ($i) => now()->subDays($i)->startOfDay())->values();
        $moves = StockMovement::where('created_at', '>=', $days->first())->get(['type', 'quantity', 'created_at']);

        $sumFor = fn (string $type) => $days->map(
            fn ($d) => (int) $moves->where('type', $type)->filter(fn ($m) => $m->created_at->isSameDay($d))->sum('quantity')
        )->values();

        $stats = [
            'products'   => Product::count(),
            'categories' => Category::count(),
            'suppliers'  => Supplier::count(),
            'low_stock'  => Product::lowStock()->count(),
            'value'      => (float) Product::sum(DB::raw('price * stock')),
            'ins_week'   => (int) $moves->where('type', StockMovement::IN)->sum('quantity'),
            'outs_week'  => (int) $moves->where('type', StockMovement::OUT)->sum('quantity'),
        ];

        $lowStock = Product::with(['category', 'supplier'])->lowStock()->orderBy('stock')->limit(6)->get();

        $latestMovements = StockMovement::with('user')->latest()->latest('id')->limit(6)->get();

        $byCategory = Category::withCount('products')->orderBy('name')->get();

        $chart = [
            'cats'     => $byCategory->pluck('name')->values(),
            'products' => $byCategory->pluck('products_count')->values(),
            'days'     => $days->map(fn ($d) => $d->translatedFormat('D d'))->values(),
            'in'       => $sumFor(StockMovement::IN),
            'out'      => $sumFor(StockMovement::OUT),
        ];

        return view('dashboard', compact('stats', 'lowStock', 'latestMovements', 'chart'));
    }
}
