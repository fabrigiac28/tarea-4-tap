<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Services\StockService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::with(['category', 'supplier'])
            ->search($request->query('q'))
            ->inCategory($request->query('category'))
            ->when($request->boolean('low'), fn ($q) => $q->lowStock())
            ->orderBy('name')
            ->paginate(10)
            ->withQueryString();

        $categories = Category::orderBy('name')->get();

        return view('products.index', compact('products', 'categories'));
    }

    public function create()
    {
        return view('products.create', $this->formData());
    }

    public function store(ProductRequest $request, StockService $stock)
    {
        $data         = $request->validated();
        $initialStock = (int) $data['stock'];

        DB::transaction(function () use ($data, $initialStock, $stock) {
            // Se crea en 0 y el stock inicial entra como un movimiento real
            $product = Product::create(array_merge($data, ['stock' => 0]));

            if ($initialStock > 0) {
                $stock->record($product, StockMovement::IN, $initialStock, 'Stock inicial');
            }
        });

        return redirect()->route('products.index')
            ->with('success', 'Producto registrado correctamente.');
    }

    public function edit(Product $product)
    {
        return view('products.edit', $this->formData() + compact('product'));
    }

    public function update(ProductRequest $request, Product $product, StockService $stock)
    {
        $data     = $request->validated();
        $newStock = (int) $data['stock'];
        unset($data['stock']);

        DB::transaction(function () use ($product, $data, $newStock, $stock) {
            $product->update($data);

            $diff = $newStock - (int) $product->stock;
            if ($diff !== 0) {
                $stock->record(
                    $product,
                    $diff > 0 ? StockMovement::IN : StockMovement::OUT,
                    abs($diff),
                    'Ajuste manual',
                    'Cambio de stock desde la edición del producto'
                );
            }
        });

        return redirect()->route('products.index')
            ->with('success', 'Producto actualizado correctamente.');
    }

    public function destroy(Product $product, StockService $stock)
    {
        DB::transaction(function () use ($product, $stock) {
            if ($product->stock > 0) {
                $stock->record($product, StockMovement::OUT, (int) $product->stock, 'Producto eliminado');
            }
            $product->delete(); // el historial queda con product_id = NULL
        });

        return redirect()->route('products.index')
            ->with('success', 'Producto eliminado correctamente.');
    }

    private function formData(): array
    {
        return [
            'categories' => Category::orderBy('name')->get(),
            'suppliers'  => Supplier::orderBy('name')->get(),
        ];
    }
}
