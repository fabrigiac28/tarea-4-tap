<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockMovement extends Model
{
    public const IN  = 'in';
    public const OUT = 'out';

    /** Motivos que el usuario puede elegir en el formulario. */
    public const REASONS = [
        self::IN  => ['Compra a proveedor', 'Devolución de cliente', 'Ajuste de inventario', 'Stock inicial'],
        self::OUT => ['Venta', 'Devolución a proveedor', 'Merma o daño', 'Ajuste de inventario'],
    ];

    protected $fillable = [
        'product_id', 'product_name', 'user_id', 'type', 'quantity',
        'stock_before', 'stock_after', 'reason', 'notes',
    ];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public static function reasonsFor(?string $type): array
    {
        return self::REASONS[$type] ?? [];
    }

    public function isEntry(): bool
    {
        return $this->type === self::IN;
    }

    public function typeLabel(): string
    {
        return $this->isEntry() ? 'Entrada' : 'Salida';
    }
}
