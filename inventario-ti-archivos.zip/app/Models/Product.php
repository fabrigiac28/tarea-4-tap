<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    /** Stock menor a este valor se considera "bajo". */
    public const LOW_STOCK = 5;

    protected $fillable = [
        'category_id',
        'supplier_id',
        'sku',
        'name',
        'price',
        'stock',
        'description',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'stock' => 'integer',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function movements(): HasMany
    {
        return $this->hasMany(StockMovement::class);
    }

    public function isLowStock(): bool
    {
        return $this->stock < self::LOW_STOCK;
    }

    /** ok | low | out  (para colores y etiquetas en las vistas). */
    public function stockStatus(): string
    {
        if ($this->stock === 0) {
            return 'out';
        }

        return $this->isLowStock() ? 'low' : 'ok';
    }

    /** Búsqueda por nombre o SKU. */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        return $query->when($term, function (Builder $q) use ($term) {
            $q->where(function (Builder $w) use ($term) {
                $w->where('name', 'like', "%{$term}%")
                  ->orWhere('sku', 'like', "%{$term}%");
            });
        });
    }

    public function scopeInCategory(Builder $query, $categoryId): Builder
    {
        return $query->when($categoryId, fn (Builder $q) => $q->where('category_id', $categoryId));
    }

    public function scopeLowStock(Builder $query): Builder
    {
        return $query->where('stock', '<', self::LOW_STOCK);
    }
}
